package interface_inheritances;

public interface IChef {
	public void Cook();
}
