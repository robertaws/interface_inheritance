package interface_inheritances;

public interface IWorker {
	public void Work();
}
