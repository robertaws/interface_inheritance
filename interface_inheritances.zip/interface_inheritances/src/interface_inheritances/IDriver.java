package interface_inheritances;

public interface IDriver {
	public void Drive();
}
