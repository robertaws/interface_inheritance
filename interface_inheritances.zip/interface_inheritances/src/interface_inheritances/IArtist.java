package interface_inheritances;

public interface IArtist {
	public void Paint();
}
