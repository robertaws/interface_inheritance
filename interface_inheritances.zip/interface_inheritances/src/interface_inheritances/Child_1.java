package interface_inheritances;

public class Child_1 extends BaseCharacter{

	public Child_1(String name, String description) {
		super(name, description);
	}


}
