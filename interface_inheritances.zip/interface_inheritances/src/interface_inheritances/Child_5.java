package interface_inheritances;

public class Child_5 extends BaseCharacter{

	public Child_5(String name, String description) {
		super(name, description);
	}


}
